
public class GiftCardItem extends Item {
    public GiftCardItem(String name, double price, int quantity, DiscountType discountType, double discountAmount){
        super(name, price, quantity, discountType, discountAmount);
    }
}
